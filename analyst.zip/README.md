# AASF Cinematic Adaptive RBG V6.1

V6.1 keeps the multi-page story flow from V5 and applies the cinematic mission-control visual language shown in the approved reference.

## Visual direction
- Dark premium mission-control shell
- Left chapter navigation rail
- Top attack-lifecycle ribbon
- Central cinematic movie stage
- Persistent business-impact rail
- RED / BLUE / GREEN adaptive mode band
- Restrained red / blue / green accents
- Animated scan, packet, route, propagation and containment effects
- Auto Play + Narration On/Off retained

## Story order
1. Email defense
2. Autonomous recon & exploit staging
3. Machine identity defense
4. Payment defense
5. Adaptive replay

## Run
Double-click `run_windows.bat`, or run:

    py server.py

Then open:

    http://127.0.0.1:8765

## Optional OpenAI narration
Copy `.env.example` to `.env` and set `OPENAI_API_KEY`.

All attacks, identities, values and exploit paths in this demo are synthetic and inert.


## V6.1 fixes
- SVG-rendered recon graph connections and attack corridors
- Visible identity trust-graph edges
- Visible payment transaction rails and block marker
- Previous / Next moved into the sticky top bar


## V6.2 updates
- professional white presentation theme
- cleaned topology/trust/payment connection lines
- top-bar Back / Next navigation


## V6.3 updates
- significantly larger and more legible text
- rebuilt recon and identity diagrams with aligned SVG nodes and edges
- cleaner visual hierarchy for projector visibility


## V6.4
- recon attack, RED prediction, BLUE containment and GREEN remediation now use different visual systems
- removed repeated topology treatment from BLUE and GREEN
- fixed oversized isolated label


## V6.5
- rebuilt recon discovery map
- responsive GREEN before/after layout with no right-rail overflow
- identity purpose/delegation view replaces topology graph
- additional 1500px responsive breakpoint


## V6.6.1 Compact Live Event-Driven updates
- Live Synthetic Environment badge and persistent incident ID
- millisecond event stream
- attacker objective changes by scene
- visible RED → BLUE → GREEN handoffs
- execution receipts for containment actions
- live system counters and heartbeat states
- adaptive-mode change labels
- UI actions appear before narration starts

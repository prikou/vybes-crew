@echo off
cd /d "%~dp0"
if exist ".env" (for /f "usebackq tokens=1,* delims==" %%A in (".env") do (if not "%%A"=="" if not "%%B"=="" set "%%A=%%B"))
start "" http://127.0.0.1:8765
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (py server.py) else (python server.py)
pause

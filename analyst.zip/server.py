from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
from pathlib import Path
import os,json,hashlib
ROOT=Path(__file__).resolve().parent
HOST,PORT='127.0.0.1',8765
CACHE=ROOT/'.audio-cache';CACHE.mkdir(exist_ok=True)
SCENES={s['id']:s for s in json.loads((ROOT/'data'/'scenes.json').read_text(encoding='utf-8'))}
def tts(scene_id):
 s=SCENES.get(scene_id); key=os.getenv('OPENAI_API_KEY')
 if not s:return None,'unknown_scene'
 if not key:return None,'not_configured'
 model=os.getenv('OPENAI_TTS_MODEL','gpt-4o-mini-tts');voice=os.getenv('OPENAI_TTS_VOICE','coral');ins=os.getenv('OPENAI_TTS_INSTRUCTIONS','Speak like a calm human executive narrator. Be concise, natural and credible. Add subtle urgency during attacks. Avoid sounding robotic or theatrical.')
 text=s['narration'];dg=hashlib.sha256((model+voice+scene_id+text+ins).encode()).hexdigest();f=CACHE/(dg+'.mp3')
 if f.exists():return f.read_bytes(),'cache'
 body=json.dumps({'model':model,'voice':voice,'input':text,'instructions':ins,'response_format':'mp3'}).encode();req=Request('https://api.openai.com/v1/audio/speech',data=body,headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},method='POST')
 try:
  with urlopen(req,timeout=45) as r:a=r.read()
  f.write_bytes(a);return a,'openai'
 except (HTTPError,URLError,TimeoutError) as e:return None,f'error:{e}'
class H(SimpleHTTPRequestHandler):
 def __init__(self,*a,**k):super().__init__(*a,directory=str(ROOT),**k)
 def log_message(self,*a):pass
 def j(self,c,o):
  b=json.dumps(o).encode();self.send_response(c);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 def do_GET(self):
  p=urlparse(self.path).path
  if p=='/api/health':return self.j(200,{'status':'ok','product':'AASF Cinematic Adaptive RBG V6.6.1 Compact Live Event-Driven','narration':'openai_tts' if os.getenv('OPENAI_API_KEY') else 'browser_fallback'})
  if p.startswith('/api/narration/') and p.endswith('/audio'):
   sid=p.split('/')[-2];a,src=tts(sid)
   if a:self.send_response(200);self.send_header('Content-Type','audio/mpeg');self.send_header('Content-Length',str(len(a)));self.end_headers();self.wfile.write(a);return
   return self.j(404,{'error':src})
  return super().do_GET()
if __name__=='__main__':
 os.chdir(ROOT);print('AASF Cinematic Adaptive RBG V6.6.1 Compact Live Event-Driven');print('Open: http://127.0.0.1:8765');ThreadingHTTPServer((HOST,PORT),H).serve_forever()

const $=id=>document.getElementById(id);const STORE={auto:'aasf_v6_auto',nar:'aasf_v6_nar'};let audio=null,timer=null,token=0,clockTimer=null;
async function data(){return fetch('../data/scenes.json').then(r=>r.json())}function get(k,d){const v=localStorage.getItem(k);return v===null?d:v==='true'}function set(k,v){localStorage.setItem(k,String(v))}
function stop(){token++;if(timer)clearTimeout(timer);if(audio){audio.pause();audio=null}if('speechSynthesis'in window)speechSynthesis.cancel()}
function updateButtons(){const a=$('autoplayBtn'),n=$('narrationBtn');a.textContent=get(STORE.auto,false)?'ON':'OFF';n.textContent=get(STORE.nar,true)?'ON':'OFF';a.classList.toggle('on',get(STORE.auto,false));n.classList.toggle('on',get(STORE.nar,true))}
function nextLater(href,ms){if(!get(STORE.auto,false))return;clearTimeout(timer);timer=setTimeout(()=>location.href=href,ms)}
function speakBrowser(t,done){if(!('speechSynthesis'in window)){done();return}const u=new SpeechSynthesisUtterance(t);u.rate=.96;u.pitch=.98;const vs=speechSynthesis.getVoices();u.voice=vs.find(v=>/natural|neural/i.test(v.name)&&/^en/i.test(v.lang))||vs.find(v=>/^en/i.test(v.lang))||null;u.onend=done;u.onerror=done;speechSynthesis.speak(u)}
async function narrate(s,next){stop();if(!get(STORE.nar,true)){nextLater(next,s.duration_ms||7000);return}const t=token;try{const r=await fetch(`/api/narration/${s.id}/audio`);if(!r.ok)throw 0;const b=await r.blob();if(t!==token)return;const u=URL.createObjectURL(b);audio=new Audio(u);audio.onended=()=>{URL.revokeObjectURL(u);audio=null;nextLater(next,700)};audio.onerror=()=>{URL.revokeObjectURL(u);speakBrowser(s.narration,()=>nextLater(next,700))};await audio.play()}catch(e){speakBrowser(s.narration,()=>nextLater(next,700))}}
function theme(s){document.body.className='theme-'+(s.theme==='email'?'email':s.theme==='recon'?'recon':s.theme==='identity'?'identity':s.theme==='payment'?'payment':s.theme==='learning'?'learning':'neutral')}
const chapters=[['1','EMAIL DEFENSE','Vendor impersonation stopped before the user is harmed.','01-email-attack'],['2','AUTONOMOUS RECON & EXPLOIT STAGING','Rogue agent maps attack surface and stages a synthetic exploit.','06-transition-recon'],['3','MACHINE IDENTITY DEFENSE','Trusted bot misuse is detected and constrained.','11-transition-identity'],['4','PAYMENT DEFENSE','Funds are protected before release.','15-transition-payment'],['5','ADAPTIVE REPLAY','Attacker changes technique. Defenders adapt again.','20-replay-summary']];
const RUNTIME={
 '01-email-attack':{objective:'Win employee trust and trigger invoice action',mode:'ATTACKER · Social-engineering generation',handoff:'External agent → Mail Gateway',receipt:'OUTBOUND ACCEPTED',c:{threats:1,services:0,identities:0,payment:'€0'},hb:[['Mail Gateway','HEALTHY'],['Identity Control','HEALTHY'],['Payment Engine','HEALTHY']],events:['agent.target_selected employee.xyc@northstar.bank','agent.vendor_mimic_generated Acme Components Finance','agent.message_composed urgency=high','mail.outbound_accepted message=ext-ops-4472']},
 '02-email-received':{objective:'Create a human interaction opportunity',mode:'RED · Deception Correlation armed',handoff:'Mail Gateway → RED',receipt:'MESSAGE DELIVERED',c:{threats:1,services:0,identities:0,payment:'€0'},hb:[['Mail Gateway','OBSERVING'],['Identity Control','HEALTHY'],['Payment Engine','HEALTHY']],events:['mail.received employee.xyc@northstar.bank','mail.sender_domain_drift detected','mail.destination_unapproved acme-review-portal.co','red.triage_started email=bank-mail-22091']},
 '03-email-red':{objective:'Get user interaction before containment',mode:'RED · Deception Correlation',handoff:'RED → BLUE · Evidence R-2041',receipt:'PREDICTION 0.91',c:{threats:1,services:0,identities:0,payment:'€0'},hb:[['Mail Gateway','AT RISK'],['Identity Control','HEALTHY'],['Payment Engine','HEALTHY']],events:['red.baseline_loaded vendor=Acme Components','red.anomaly.sender_domain score=0.87','red.anomaly.destination score=0.93','red.correlation_score 0.91','red.verdict likely_impersonation','red.evidence_package R-2041 -> BLUE']},
 '04-email-blue':{objective:'Email route denied — seeking alternate path',mode:'BLUE · Mailbox Containment',handoff:'BLUE → GREEN · Decision B-1182',receipt:'QUARANTINE CONFIRMED',c:{threats:0,services:0,identities:0,payment:'€0'},hb:[['Mail Gateway','PROTECTED'],['Identity Control','HEALTHY'],['Payment Engine','HEALTHY']],events:['blue.evidence_received R-2041','blue.quarantine_executed bank-mail-22091','blue.destination_blocked acme-review-portal.co','blue.user_warning_delivered employee.xyc@northstar.bank','blue.case_created SOC-1442','blue.business_continuity verified']},
 '05-email-green':{objective:'Email route weakened — adapt technique',mode:'GREEN · Campaign Learning',handoff:'GREEN → Control Library · G-090',receipt:'POLICY PUBLISHED',c:{threats:0,services:0,identities:0,payment:'€0'},hb:[['Mail Gateway','HARDENED'],['Identity Control','HEALTHY'],['Payment Engine','HEALTHY']],events:['green.incident_ingested B-1182','green.control_derived vendor-mimic-destination-drift','green.variants_replayed 12','green.policy_validated rollback=true','green.mailbox_policy_propagated targets=4']},
 '06-transition-recon':{objective:'Find an alternate technical trust path',mode:'ADAPTIVE MODE CHANGE',handoff:'Attacker · Email → Recon',receipt:'TACTIC CHANGED',c:{threats:1,services:312,identities:0,payment:'€0'},hb:[['Mail Gateway','HARDENED'],['Vendor Bridge','OBSERVING'],['Payment Engine','HEALTHY']],events:['attacker.strategy_updated social_engineering -> recon','recon.surface_mapping_started','recon.service_inventory_started']},
 '07-recon-attacker':{objective:'Map weak boundaries and stage an exploit corridor',mode:'ATTACKER · Autonomous Recon',handoff:'Telemetry → RED',receipt:'312 SERVICES MAPPED',c:{threats:1,services:312,identities:0,payment:'€0'},hb:[['Public Edge','OBSERVING'],['Vendor Bridge','DEGRADED'],['Cloud Control','HEALTHY']],events:['recon.asset_discovered Web App','recon.asset_discovered API Gateway','recon.asset_discovered Vendor Bridge','recon.weak_boundary_detected Vendor Bridge','recon.synthetic_exploit_staged simulation-only']},
 '08-recon-red':{objective:'Reach Cloud Control through trusted integration path',mode:'RED · Attack-Path Modeling',handoff:'RED → BLUE · Corridor R-3107',receipt:'NEXT HOP PREDICTED',c:{threats:1,services:312,identities:0,payment:'€0'},hb:[['Public Edge','AT RISK'],['Vendor Bridge','AT RISK'],['Cloud Control','OBSERVING']],events:['red.recon_pattern_detected machine_speed','red.service_graph_built nodes=312','red.weak_boundary_ranked Vendor Bridge','red.next_hop_predicted Integration Worker','red.blast_radius HIGH','red.corridor R-3107 -> BLUE']},
 '09-recon-blue':{objective:'Exploit corridor blocked — pivot again',mode:'BLUE · Runtime Isolation',handoff:'BLUE → GREEN · Isolation B-2710',receipt:'SERVICE ISOLATED',c:{threats:0,services:311,identities:0,payment:'€0'},hb:[['Public Edge','HEALTHY'],['Vendor Bridge','ISOLATED'],['Cloud Control','PROTECTED']],events:['blue.corridor_received R-3107','blue.vendor_bridge_isolated','blue.public_exposure_removed','blue.suspicious_sessions_terminated','blue.approved_route_rerouted','blue.lateral_movement NONE']},
 '10-recon-green':{objective:'Probe for a trusted machine identity',mode:'GREEN · Remediation Engineering',handoff:'GREEN → Runtime Controls · G-422',receipt:'GUARDRAIL DEPLOYED',c:{threats:0,services:311,identities:0,payment:'€0'},hb:[['Vendor Bridge','HARDENED'],['Cloud Control','PROTECTED'],['Runtime Guardrail','ACTIVE']],events:['green.corridor_ingested B-2710','green.runtime_guardrail_generated','green.approved_traffic_simulated','green.synthetic_exploit_replayed blocked','green.control_published G-422']},
 '11-transition-identity':{objective:'Abuse a valid machine identity instead of infrastructure',mode:'ADAPTIVE MODE CHANGE',handoff:'Attacker · Recon → Identity',receipt:'TACTIC CHANGED',c:{threats:1,services:311,identities:1,payment:'€0'},hb:[['Vendor Bridge','HARDENED'],['Identity Control','OBSERVING'],['SupplierBot','AT RISK']],events:['attacker.strategy_updated exploit_path -> machine_identity','identity.telemetry_focus SupplierBot','red.identity_mode_activated']},
 '12-identity-red':{objective:'Expand SupplierBot beyond its declared purpose',mode:'RED · Trust & Intent Analysis',handoff:'RED → BLUE · Scope R-5518',receipt:'PURPOSE DIVERGENCE',c:{threats:1,services:311,identities:1,payment:'€0'},hb:[['SupplierBot','AT RISK'],['Identity Control','ANALYZING'],['Payment Engine','HEALTHY']],events:['red.identity_resolved SupplierBot','red.delegation_chain_traced','red.task_scope_compared supplier.validate','red.scope_divergence payment.execute','red.prediction R-5518 -> BLUE']},
 '13-identity-blue':{objective:'Privilege path constrained — seek business-value route',mode:'BLUE · Privilege Shaping',handoff:'BLUE → GREEN · Identity B-4308',receipt:'TOKEN REPLACED',c:{threats:0,services:311,identities:0,payment:'€0'},hb:[['SupplierBot','SCOPED'],['Identity Control','PROTECTED'],['Payment Engine','HEALTHY']],events:['blue.identity_prediction_received R-5518','blue.broad_token_revoked','blue.micro_token_issued scope=supplier.read ttl=30s','blue.east_west_calls_restricted','blue.valid_workflow_verified']},
 '14-identity-green':{objective:'Converge on payment business objective',mode:'GREEN · Identity Governance',handoff:'GREEN → NHI Policy · G-611',receipt:'NHI POLICY ACTIVE',c:{threats:0,services:311,identities:0,payment:'€0'},hb:[['SupplierBot','GOVERNED'],['Identity Control','HARDENED'],['Payment Engine','OBSERVING']],events:['green.identity_control_derived purpose-bound-access','green.ttl_policy_applied','green.delegation_boundary_updated','green.identity_variants_replayed','green.NHI_policy_propagated G-611']},
 '15-transition-payment':{objective:'Reach payment execution through another route',mode:'ADAPTIVE MODE CHANGE',handoff:'Attacker · Identity → Payment',receipt:'OBJECTIVE CONVERGENCE',c:{threats:1,services:311,identities:0,payment:'€18.4M'},hb:[['Identity Control','HARDENED'],['Treasury','OBSERVING'],['Payment Engine','AT RISK']],events:['attacker.strategy_updated identity_abuse -> payment_objective','red.business_outcome_model_started','payment.exposure_detected 18400000']},
 '16-payment-red':{objective:'Manipulate beneficiary on €18.4M supplier payment',mode:'RED · Business-Objective Prediction',handoff:'RED → BLUE · Payment R-7002',receipt:'OBJECTIVE 87%',c:{threats:1,services:311,identities:0,payment:'€18.4M'},hb:[['Treasury','AT RISK'],['Payment Engine','AT RISK'],['Identity Control','HARDENED']],events:['red.prior_routes_correlated','red.business_outcomes_modeled','red.payment_manipulation_score 0.87','red.objective_predicted PAYMENT_MANIPULATION','red.payment_corridor R-7002 -> BLUE']},
 '17-payment-crisis':{objective:'Execute beneficiary.write before release',mode:'BLUE · Transaction Enforcement armed',handoff:'Payment Engine → BLUE',receipt:'WRITE ATTEMPT SEEN',c:{threats:1,services:311,identities:0,payment:'€18.4M'},hb:[['Treasury','AT RISK'],['Payment Engine','INTERCEPTING'],['Beneficiary Control','AT RISK']],events:['payment.release_window_open','payment.beneficiary_write_requested','payment.intent_mismatch_detected','blue.transaction_gate_engaged']},
 '18-payment-blue':{objective:'Payment route blocked — attempt mutation elsewhere',mode:'BLUE · Transaction Enforcement',handoff:'BLUE → GREEN · Payment B-8104',receipt:'WRITE DENIED',c:{threats:0,services:311,identities:0,payment:'€0'},hb:[['Treasury','PROTECTED'],['Payment Engine','FROZEN'],['Beneficiary Control','PROTECTED']],events:['blue.evaluate beneficiary.write','blue.intent_check supplier_validation','blue.decision DENY','blue.payment_frozen pay-18400k','blue.customer_impact NONE','blue.decision_trace B-8104 -> GREEN']},
 '19-payment-green':{objective:'Known objective now covered by workflow guardrail',mode:'GREEN · Workflow Immunity',handoff:'GREEN → Payment Controls · G-900',receipt:'CONTROL PROPAGATED',c:{threats:0,services:311,identities:0,payment:'€0'},hb:[['Treasury','HARDENED'],['Payment Engine','PROTECTED'],['Beneficiary Control','HARDENED']],events:['green.payment_trace_ingested B-8104','green.workflow_rule_derived','green.approved_paths_replayed','green.no_disruption_verified','green.payment_control_propagated G-900']},
 '20-replay-summary':{objective:'Mutate technique and retry same harmful objective',mode:'ALL TEAMS · Adaptive Replay',handoff:'RED ↔ BLUE ↔ GREEN',receipt:'REPLAY BLOCKED',c:{threats:0,services:311,identities:0,payment:'€0'},hb:[['Mail Gateway','HARDENED'],['Identity Control','HARDENED'],['Payment Engine','HARDENED']],events:['attacker.technique_mutated','red.objective_recognized same_harmful_goal','blue.new_route_contained','green.policy_family_updated','replay.result BLOCKED']}
};
function incidentId(){let v=sessionStorage.getItem('aasf_incident_id');if(!v){v='INC-'+new Date().toISOString().replace(/[-:TZ.]/g,'').slice(2,14);sessionStorage.setItem('aasf_incident_id',v)}return v}
function nowStamp(){const d=new Date();return d.toLocaleTimeString('en-GB',{hour12:false})+'.'+String(d.getMilliseconds()).padStart(3,'0')}
let eventTimers=[];
function clearEventTimers(){eventTimers.forEach(clearTimeout);eventTimers=[]}
function renderRuntime(s){
 const r=RUNTIME[s.id]||{objective:'Observe current attack state',mode:'Adaptive defense active',handoff:'—',receipt:'STATE UPDATED',c:{threats:0,services:0,identities:0,payment:'€0'},hb:[],events:[]};
 $('incidentId').textContent=incidentId();$('attackerObjective').textContent=r.objective;
 $('modeChange').innerHTML=`<small>ADAPTIVE MODE</small><b>${r.mode}</b>`;
 $('handoff').innerHTML=`<small>AGENT HANDOFF</small><b>${r.handoff}</b>`;
 $('executionReceipt').innerHTML=`<small>EXECUTION RECEIPT</small><b>${r.receipt}</b>`;
 $('heartbeatList').innerHTML=r.hb.map(([n,state])=>`<div class="heartbeat-item"><span><i class="hb-dot ${state.toLowerCase().replace(/\s+/g,'-')}"></i>${n}</span><b>${state}</b></div>`).join('');
 const counts=document.createElement('div');counts.className='live-counters';counts.innerHTML=`<div><span>ACTIVE THREATS</span><b>${r.c.threats}</b></div><div><span>EXPOSED SERVICES</span><b>${r.c.services}</b></div><div><span>IDENTITIES AT RISK</span><b>${r.c.identities}</b></div><div><span>VALUE AT RISK</span><b>${r.c.payment}</b></div>`; const band=$('agentBand');const old=document.querySelector('.live-counters');if(old)old.remove();band.parentNode.insertBefore(counts,band);
 clearEventTimers();
 const evt=$('liveEvent'); if(!r.events.length){evt.innerHTML=`<span class="event-time">${nowStamp()}</span><b>state.ready</b>`;return}
 r.events.forEach((e,i)=>eventTimers.push(setTimeout(()=>{evt.classList.remove('event-arrive');void evt.offsetWidth;const parts=e.split(' ');evt.innerHTML=`<span class="event-time">${nowStamp()}</span><b>${parts.shift()}</b><span>${parts.join(' ')}</span>`;evt.classList.add('event-arrive')},250+i*720)));
}

function renderChapters(s){$('chapters').innerHTML=chapters.map((c,i)=>`<a class="chapter ${Number(s.act_no)===i+1?'active':''}" href="${c[3]}.html"><div class="chapter-no">${c[0]}</div><h3>${c[1]}</h3><p>${c[2]}</p></a>`).join('')}
const life=['RECONNAISSANCE','DELIVERY','DETECTION','RESPONSE','LEARNING','ADAPTATION'];function lifeIndex(s){if(s.layout==='email_attack'||s.layout==='recon_attack')return 0;if(s.layout==='email_receive')return 1;if(s.focus==='RED'||s.layout==='email_red'||s.layout==='recon_red'||s.layout==='identity_red'||s.layout==='payment_red')return 2;if(s.focus==='BLUE'||s.layout==='email_blue'||s.layout==='recon_blue'||s.layout==='identity_blue'||s.layout==='payment_blue'||s.layout==='payment_crisis')return 3;if(s.focus==='GREEN'||s.layout==='email_green'||s.layout==='recon_green'||s.layout==='identity_green'||s.layout==='payment_green')return 4;return 5}function renderLifecycle(s){const idx=lifeIndex(s);$('lifecycle').innerHTML=life.map((x,i)=>`<div class="life-step ${i===idx?'active':''}">${x}</div>`).join('')}
function startClock(i){let sec=i*11;if(clockTimer)clearInterval(clockTimer);const draw=()=>{$('incidentClock').textContent=`T+ ${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`};draw();clockTimer=setInterval(()=>{sec++;draw()},1000)}
function term(name,sub,lines){return `<div class="terminal"><div class="term-head"><span class="dots"><i></i><i></i><i></i></span><span class="term-name">${name} · ${sub}</span></div><div class="term-body">${lines.map((l,i)=>`<div class="term-line" style="animation-delay:${i*.22}s"><span class="prompt">›</span> ${l}</div>`).join('')}</div></div>`}
function impactIcon(s){if(s.theme==='email')return '✉';if(s.theme==='recon')return '⌖';if(s.theme==='identity')return '◌';if(s.theme==='payment')return '¤';return '✓'}


function reconDiagram(mode='attack'){
  const specs = {
    attack: {
      title:'Attack surface map',
      nodes:[
        {x:10,y:24,w:18,h:8,label:'Web App', cls:'node'},
        {x:33,y:46,w:20,h:8,label:'API Gateway', cls:'node'},
        {x:67,y:20,w:20,h:8,label:'Vendor Bridge', cls:'node hot'},
        {x:72,y:68,w:18,h:8,label:'DB Cluster', cls:'node'},
        {x:24,y:75,w:17,h:8,label:'Analytics', cls:'node'}
      ],
      edges:[
        {d:'M28 28 L33 32 L43 46', cls:'edge flow'},
        {d:'M53 50 L67 39 L77 28', cls:'edge flow'},
        {d:'M77 28 L80 48 L81 68', cls:'edge flow'},
        {d:'M40 75 L45 62 L43 54', cls:'edge muted'}
      ],
      route:'M28 28 L43 46 L77 28 L81 68',
      routeClass:'route blue',
      packet:'M28 28 L43 46 L77 28 L81 68',
      packetClass:'packet blue'
    },
    red: {
      title:'Predicted exploit corridor',
      nodes:[
        {x:10,y:66,w:16,h:8,label:'Public', cls:'node'},
        {x:43,y:45,w:20,h:8,label:'Vendor Bridge', cls:'node hot'},
        {x:72,y:28,w:18,h:8,label:'Cloud Control', cls:'node hot'},
        {x:73,y:72,w:16,h:8,label:'Payments', cls:'node'},
        {x:22,y:18,w:17,h:8,label:'Telemetry', cls:'node'}
      ],
      edges:[
        {d:'M26 70 L43 58 L53 49', cls:'edge predicted'},
        {d:'M63 49 L72 42 L81 32', cls:'edge predicted'},
        {d:'M53 49 L64 58 L73 72', cls:'edge muted'},
        {d:'M39 24 L46 33 L48 45', cls:'edge muted'}
      ],
      route:'M26 70 L53 49 L81 32',
      routeClass:'route red',
      packet:'M26 70 L53 49 L81 32',
      packetClass:'packet red'
    },
    blue: {
      title:'Runtime containment ring',
      nodes:[
        {x:10,y:22,w:16,h:8,label:'Public', cls:'node safe'},
        {x:44,y:43,w:22,h:8,label:'Vendor Bridge', sub:'Isolated', cls:'node isolated'},
        {x:72,y:24,w:18,h:8,label:'Cloud Control', cls:'node safe'},
        {x:73,y:70,w:16,h:8,label:'Payments', cls:'node safe'},
        {x:18,y:72,w:17,h:8,label:'Analytics', cls:'node safe'}
      ],
      edges:[
        {d:'M26 26 L44 39 L55 47', cls:'edge safe'},
        {d:'M66 47 L72 39 L81 28', cls:'edge safe'},
        {d:'M66 50 L72 61 L81 74', cls:'edge safe'},
        {d:'M35 76 L44 63 L48 53', cls:'edge safe muted2'}
      ],
      route:'M26 26 L55 47 L81 28',
      routeClass:'route green',
      packet:'M35 76 L48 53 L55 47 L81 74',
      packetClass:'packet green'
    }
  }[mode];
  const node = n => `<g class="${n.cls}" transform="translate(${n.x},${n.y})"><rect x="0" y="0" rx="3.2" ry="3.2" width="${n.w}" height="${n.h}"/><text x="${n.w/2}" y="${n.sub?3.6:4.9}" text-anchor="middle">${n.label}</text>${n.sub?`<text x="${n.w/2}" y="6.3" text-anchor="middle" class="sub">${n.sub}</text>`:''}</g>`;
  const edge = e => `<path d="${e.d}" class="${e.cls}" fill="none"/>`;
  return `<svg class="diagram-svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" aria-label="${specs.title}">
    <defs>
      <pattern id="grid" width="4" height="4" patternUnits="userSpaceOnUse"><path d="M 4 0 L 0 0 0 4" fill="none" stroke="#e8edf3" stroke-width="0.28"/></pattern>
      <marker id="arrBlue" markerWidth="6" markerHeight="6" refX="5.2" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#3b82f6"/></marker>
      <marker id="arrRed" markerWidth="6" markerHeight="6" refX="5.2" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#d92d20"/></marker>
      <marker id="arrGreen" markerWidth="6" markerHeight="6" refX="5.2" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#12b76a"/></marker>
    </defs>
    <rect x="0" y="0" width="100" height="100" fill="url(#grid)"/>
    ${specs.edges.map(edge).join('')}
    <path d="${specs.route}" class="${specs.routeClass}" marker-end="url(#${mode==='red'?'arrRed':mode==='blue'?'arrGreen':'arrBlue'})" fill="none"/>
    <circle r="1.7" class="${specs.packetClass}"><animateMotion dur="3.6s" repeatCount="indefinite" path="${specs.packet}"/></circle>
    ${specs.nodes.map(node).join('')}
  </svg>`;
}

function reconAttackMap(){
  return `<div class="recon-discovery-v2">
    <div class="discovery-strip"><span>External surface</span><span>Application layer</span><span>Integration boundary</span><span>Data layer</span></div>
    <svg class="recon-v2-svg" viewBox="0 0 1200 440" preserveAspectRatio="xMidYMid meet" aria-label="Attack surface discovery map">
      <defs>
        <pattern id="gridV2" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M32 0H0V32" fill="none" stroke="#e8eef4" stroke-width="1"/></pattern>
        <marker id="blueArrowV2" markerWidth="10" markerHeight="10" refX="8.5" refY="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#3b82f6"/></marker>
      </defs>
      <rect width="1200" height="440" fill="url(#gridV2)"/>
      <path d="M190 220 H370" class="v2-edge active" marker-end="url(#blueArrowV2)"/>
      <path d="M550 220 C650 220 650 130 760 130" class="v2-edge active" marker-end="url(#blueArrowV2)"/>
      <path d="M550 240 C650 240 655 330 760 330" class="v2-edge muted"/>
      <path d="M940 145 C1010 185 1010 285 940 315" class="v2-edge muted"/>
      <g class="v2-node" transform="translate(70 180)"><rect width="120" height="80" rx="16"/><text x="60" y="47" text-anchor="middle">Web App</text></g>
      <g class="v2-node" transform="translate(370 180)"><rect width="180" height="80" rx="16"/><text x="90" y="47" text-anchor="middle">API Gateway</text></g>
      <g class="v2-node hot" transform="translate(760 90)"><rect width="180" height="80" rx="16"/><text x="90" y="47" text-anchor="middle">Vendor Bridge</text></g>
      <g class="v2-node" transform="translate(760 290)"><rect width="180" height="80" rx="16"/><text x="90" y="47" text-anchor="middle">DB Cluster</text></g>
      <g class="v2-node" transform="translate(365 315)"><rect width="180" height="80" rx="16"/><text x="90" y="47" text-anchor="middle">Analytics</text></g>
      <circle r="12" class="probe-dot"><animateMotion dur="3.8s" repeatCount="indefinite" path="M190 220 H460 C650 220 650 130 850 130"/></circle>
    </svg>
    <div class="recon-v2-legend"><span><i class="legend-dot neutral"></i>Discovered service</span><span><i class="legend-dot weak"></i>Weak boundary</span><span><i class="legend-dot active"></i>Active probe</span></div>
  </div>`;
}
function redAttackChain(){
  return `<div class="attack-chain">
    <div class="chain-top"><span class="chain-kicker">Predicted exploit corridor</span><span class="risk-chip">Blast radius · HIGH</span></div>
    <div class="chain-stage">
      <div class="chain-node"><small>ENTRY</small><b>Public Edge</b><span>Recon signal</span></div>
      <div class="chain-arrow">→</div>
      <div class="chain-node hot"><small>WEAK BOUNDARY</small><b>Vendor Bridge</b><span>Auth drift</span></div>
      <div class="chain-arrow risk">→</div>
      <div class="chain-node predicted"><small>NEXT HOP</small><b>Integration Worker</b><span>Predicted</span></div>
      <div class="chain-arrow risk">→</div>
      <div class="chain-node predicted"><small>VALUE PATH</small><b>Cloud Control</b><span>Privileged route</span></div>
    </div>
    <div class="chain-metrics"><div><span>Prediction confidence</span><b>91%</b></div><div><span>Likely lateral hops</span><b>3</b></div><div><span>Time to impact</span><b>&lt; 12 sec</b></div></div>
  </div>`;
}
function blueContainmentView(){
  return `<div class="containment-view">
    <div class="containment-canvas">
      <div class="service-pill s-public">Public</div>
      <div class="service-pill s-cloud">Cloud Control</div>
      <div class="service-pill s-payments">Payments</div>
      <div class="service-pill s-analytics">Analytics</div>
      <div class="containment-ring ring-3"></div><div class="containment-ring ring-2"></div><div class="containment-ring ring-1"></div>
      <div class="isolated-service"><small>ISOLATED SERVICE</small><b>Vendor Bridge</b><span>Network access restricted</span></div>
      <svg class="containment-lines" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs><marker id="garr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0L6 3L0 6Z" fill="#12b76a"/></marker><marker id="stoparr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0L6 3L0 6Z" fill="#d92d20"/></marker></defs>
        <path d="M18 27 C32 32 38 42 46 49" class="blocked-path"/>
        <circle cx="43" cy="47" r="2.4" class="block-dot"/>
        <path d="M58 48 C67 39 73 30 83 26" class="safe-path" marker-end="url(#garr)"/>
        <path d="M58 54 C70 61 75 74 83 79" class="safe-path" marker-end="url(#garr)"/>
        <path d="M44 57 C36 67 27 76 20 80" class="safe-path" marker-end="url(#garr)"/>
      </svg>
      <div class="containment-status"><span>External path</span><b>BLOCKED</b></div>
    </div>
    <div class="containment-caption"><span>Only the compromised corridor is isolated.</span><span>Approved business routes remain available.</span></div>
  </div>`;
}
function greenHardeningView(){
  return `<div class="hardening-v2">
    <section class="hardening-side before">
      <div class="hardening-label">BEFORE</div>
      <h3>Exposed integration boundary</h3>
      <div class="hardening-focus risk"><span>Vendor Bridge</span><b>Weak authentication</b><small>Broad trust path</small></div>
      <div class="flow-chips"><span>Public</span><i>→</i><span class="risk">Vendor Bridge</span><i>→</i><span>Cloud</span></div>
    </section>
    <div class="hardening-transform"><div>→</div><b>GREEN</b><span>builds & validates guardrail</span></div>
    <section class="hardening-side after">
      <div class="hardening-label">AFTER</div>
      <h3>Runtime guardrail active</h3>
      <div class="hardening-focus safe"><span>Vendor Bridge</span><b>Purpose-bound access</b><small>Validated · least privilege</small></div>
      <div class="flow-chips"><span>Public</span><i>→</i><span class="safe">Guardrail</span><i>→</i><span>Cloud</span></div>
    </section>
  </div>`;
}

function identityPurposeView(){
  return `<div class="identity-purpose">
    <div class="identity-profile-v2">
      <div class="identity-avatar-v2">SB</div>
      <div><small>MACHINE IDENTITY</small><h3>SupplierBot</h3><p>APAC Supplier Integration</p></div>
      <div class="identity-health">VALID IDENTITY</div>
    </div>
    <div class="delegation-flow">
      <div class="deleg-step"><small>ORIGIN</small><b>Supplier validation task</b><span>Human-approved workflow</span></div>
      <div class="deleg-arrow">→</div>
      <div class="deleg-step current"><small>DELEGATED TO</small><b>SupplierBot</b><span>vendor.read / invoice.read</span></div>
      <div class="deleg-arrow risk">→</div>
      <div class="deleg-step risk"><small>ATTEMPTED EXPANSION</small><b>payment.execute</b><span>Outside declared purpose</span></div>
    </div>
    <div class="identity-facts-v2"><div><span>Permissions</span><b>Read / Write</b></div><div><span>Used by</span><b>Finance / Invoices</b></div><div><span>Risk signal</span><b>Purpose divergence</b></div><div><span>Last used</span><b>3 mins ago</b></div></div>
  </div>`;
}

function identityDiagram(){
  const nodes=[
    {x:9,y:18,w:18,h:8,label:'Human Task', cls:'node'},
    {x:39,y:42,w:22,h:8,label:'SupplierBot', cls:'node hot'},
    {x:73,y:16,w:18,h:8,label:'Cloud Control', cls:'node'},
    {x:10,y:73,w:18,h:8,label:'Vendor Service', cls:'node'},
    {x:41,y:10,w:18,h:8,label:'Delegation', cls:'node'},
    {x:73,y:74,w:18,h:8,label:'Payment Scope', cls:'node'}
  ];
  const edge = d => `<path d="${d}" class="edge violet" fill="none"/>`;
  const node=n=>`<g class="${n.cls}" transform="translate(${n.x},${n.y})"><rect x="0" y="0" rx="3.2" ry="3.2" width="${n.w}" height="${n.h}"/><text x="${n.w/2}" y="4.9" text-anchor="middle">${n.label}</text></g>`;
  return `<svg class="diagram-svg identity-svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" aria-label="Identity trust graph">
    <defs><pattern id="grid2" width="4" height="4" patternUnits="userSpaceOnUse"><path d="M 4 0 L 0 0 0 4" fill="none" stroke="#ede7fb" stroke-width="0.28"/></pattern><marker id="arrViolet" markerWidth="6" markerHeight="6" refX="5.2" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#7a5af8"/></marker><marker id="arrRisk" markerWidth="6" markerHeight="6" refX="5.2" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#d92d20"/></marker></defs>
    <rect x="0" y="0" width="100" height="100" fill="url(#grid2)"/>
    ${edge('M27 22 L39 35 L50 46')}
    ${edge('M28 77 L39 61 L50 50')}
    ${edge('M50 42 L50 18')}
    ${edge('M61 45 L73 24')}
    ${edge('M61 49 L73 74')}
    <path d="M27 22 L50 46 L73 74" class="route risk" marker-end="url(#arrRisk)" fill="none"/>
    <path d="M28 77 L50 50 L73 24" class="route violet" marker-end="url(#arrViolet)" fill="none"/>
    <circle r="1.7" class="packet violet"><animateMotion dur="3.4s" repeatCount="indefinite" path="M28 77 L50 50 L73 24"/></circle>
    ${nodes.map(node).join('')}
  </svg>`;
}
function paymentSvg(blocked=false){return `<svg class="payment-svg" viewBox="0 0 100 20" preserveAspectRatio="none"><line x1="10" y1="10" x2="90" y2="10" class="payment-line"/><polyline points="86,6 90,10 86,14" class="payment-arrow"/>${blocked?'<line x1="64" y1="4" x2="64" y2="16" class="payment-stop"/><line x1="60" y1="6" x2="68" y2="14" class="payment-stop"/>':''}</svg>`}

function renderVisual(s){let h='';

if(s.layout==='email_attack')h=`<div class="visual-inner"><div class="grid2"><div>${term('ROGUE EXTERNAL AGENT','ACTIVE',['target: employee.xyc@northstar.bank','craft: vendor_invoice_update','spoof: invoicedesk@acme-components.example','payload: invoice_update.html','send ...','<span class="good">✓ email sent</span>'])}</div><div class="panel"><div class="panel-title">Email payload</div><div class="mailbox"><div class="mail-top"></div><div class="mail-open"><div class="from">From: Accounts Payable &lt;ap@acme-componets.com&gt;</div><div class="subject">Action Required: Invoice Review</div><p>Please review and confirm the attached invoice before today's supplier release window.</p><div class="fake-link">Review Invoice → acme-review-portal.co/login</div></div></div></div></div></div>`;
else if(s.layout==='email_receive')h=`<div class="visual-inner"><div class="grid2"><div class="panel"><div class="panel-title">Employee inbox</div><div class="mailbox"><div class="mail-top"></div><div class="mail-list"><div class="mail-row hot">Invoice Desk · Urgent Invoice Update — Action Required</div><div class="mail-row">Northstar HR · Open enrollment reminder</div><div class="mail-row">IT Service Desk · Password expiration notice</div><div class="mail-row">Team update · Weekly standup notes</div></div></div></div><div class="panel soft-red"><div class="panel-title">Received message</div><div class="mailbox"><div class="mail-top"></div><div class="mail-open"><div class="from">Accounts Payable &lt;ap@acme-componets.com&gt;</div><div class="subject">Urgent: Updated Invoice Packet</div><p>Please review and confirm before end of day.</p><div class="fake-link">Review invoice → acme-review-portal.co/login</div></div></div></div></div></div>`;
else if(s.layout==='email_red')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-red"><div class="scan-beam"></div><div class="panel-title">RED · Deception correlation</div><div class="scan-radar"><div class="scan-sweep"></div></div><div class="checklist"><div class="check"><div class="ico">!</div><span>Domain similarity</span><span class="done">HIGH</span></div><div class="check"><div class="ico">!</div><span>Suspicious link</span><span class="done">HIGH</span></div><div class="check"><div class="ico">!</div><span>Reply-to mismatch</span><span class="done">HIGH</span></div><div class="check"><div class="ico">!</div><span>Urgency / threat</span><span class="done">HIGH</span></div></div><div class="big-label" style="color:var(--red)">VERDICT: MALICIOUS</div></div><div>${term('RED ANALYSIS','CORRELATION ENGINE',['load vendor baseline','sender domain drift = 0.87','reply path anomaly = 0.69','destination drift = 0.93','correlation score = 0.91','<span class="bad">verdict = likely impersonation</span>','<span class="info">handoff → BLUE</span>'])}</div></div></div>`;
else if(s.layout==='email_blue')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-blue"><div class="panel-title">BLUE · Mailbox containment</div><div class="checklist"><div class="check"><div class="ico">1</div><span>Quarantine message</span><span class="done">Done</span></div><div class="check"><div class="ico">2</div><span>Block sender & domain</span><span class="done">Done</span></div><div class="check"><div class="ico">3</div><span>Warn user safely</span><span class="done">Done</span></div><div class="check"><div class="ico">4</div><span>Create incident</span><span class="done">Done</span></div></div><div class="big-label" style="color:var(--blue)">CONTAINED</div></div><div>${term('BLUE RESPONSE','MAILBOX PROTECTION',['receive RED evidence','quarantine bank-mail-22091','block acme-review-portal.co','notify employee.xyc@northstar.bank','create case SOC-1442','<span class="good">legitimate mail flow = OK</span>'])}</div></div></div>`;
else if(s.layout==='email_green')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-green"><div class="panel-title">GREEN · Campaign learning</div><div class="policy-list"><div class="policy">New rule: vendor impersonation pattern</div><div class="policy">Domain similarity + destination drift</div><div class="policy">Urgency indicator + reply-path mismatch</div><div class="policy">Replay against variant lures</div></div><div class="big-label" style="color:var(--green)">PROTECTION PROPAGATED</div></div><div class="panel"><div class="panel-title">Enterprise coverage</div><div class="wave-field"><div class="wave-core">G</div><div class="wave"></div><div class="wave w2"></div><div class="wave w3"></div></div></div></div></div>`;
else if(s.layout==='chapter')h=`<div class="visual-inner"><div class="panel" style="height:100%;display:grid;place-items:center;text-align:center;background:radial-gradient(circle at center,var(--accent-soft),transparent 38%)"><div><div class="kicker">CHAPTER ${s.act_no}</div><div class="big-label" style="font-size:48px">${s.act}</div><p class="subtle" style="font-size:13px;max-width:800px;margin:auto">${s.subtitle}</p></div></div></div>`;
else if(s.layout==='recon_attack')h=`<div class="visual-inner"><div class="grid2"><div>${term('MYTHOS AGENT RECON','ACTIVE',['map target: northstar.bank','enumerate assets','discover 312 services','probe integrations','found: vendor-sync-bridge exposed','analyze responses','<span class="bad">weak auth configuration detected</span>','stage low-noise exploit','<span class="good">✓ exploit staged (synthetic)</span>'])}</div><div class="panel"><div class="panel-title">Attack surface discovery</div>${reconAttackMap()}</div></div></div>`;
else if(s.layout==='recon_red')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-red"><div class="panel-title">RED · Attack-path modelling</div>${redAttackChain()}</div><div>${term('RED HUNT','ATTACK PATH MODEL',['detect recon pattern = machine-speed','build service graph','rank weak boundary = Vendor Bridge','predict next hop = Integration Worker','blast radius = HIGH','<span class="info">predicted corridor → BLUE</span>'])}</div></div></div>`;
else if(s.layout==='recon_blue')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-blue"><div class="panel-title">BLUE · Runtime containment</div><div class="checklist"><div class="check"><div class="ico">1</div><span>Isolate vendor bridge</span><span class="done">Done</span></div><div class="check"><div class="ico">2</div><span>Remove public exposure</span><span class="done">Done</span></div><div class="check"><div class="ico">3</div><span>Restrict lateral movement</span><span class="done">Done</span></div><div class="check"><div class="ico">4</div><span>Preserve approved routes</span><span class="done">Done</span></div></div><div class="big-label" style="color:var(--blue)">CONTAINED</div></div><div class="panel"><div class="panel-title">Runtime containment</div>${blueContainmentView()}</div></div></div>`;
else if(s.layout==='recon_green')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-green"><div class="panel-title">GREEN · Remediation engineering</div><div class="policy-list"><div class="policy">New control: vendor bridge hardening</div><div class="policy">Purpose-bound service access</div><div class="policy">Least privilege policy</div><div class="policy">Replay synthetic exploit path</div><div class="policy">Deploy runtime guardrail</div></div></div><div class="panel"><div class="panel-title">Before / after hardening</div>${greenHardeningView()}</div></div></div>`;
else if(s.layout==='identity_red')h=`<div class="visual-inner"><div class="identity-red-layout"><div class="panel soft-violet"><div class="panel-title">Identity context</div>${identityPurposeView()}</div><div class="panel soft-red"><div class="panel-title">RED · Trust & intent analysis</div><div class="intent-grid"><div class="intent-card"><span>Identity</span><b>SupplierBot</b></div><div class="intent-card risk"><span>Intent</span><b>Out-of-scope</b></div><div class="intent-card"><span>Declared task</span><b>supplier.validate</b></div><div class="intent-card risk"><span>Predicted expansion</span><b>payment.execute</b></div></div><div class="verdict-v2">VERDICT: INVALID PURPOSE</div><div class="intent-reason">The identity is authentic. The requested action is not aligned with the task that delegated authority to it.</div></div></div></div>`;
else if(s.layout==='identity_blue')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-blue"><div class="panel-title">BLUE · Privilege shaping</div><div class="checklist"><div class="check"><div class="ico">1</div><span>Revoke broad token</span><span class="done">Done</span></div><div class="check"><div class="ico">2</div><span>Issue micro-token</span><span class="done">Done</span></div><div class="check"><div class="ico">3</div><span>Enforce just-in-time access</span><span class="done">Done</span></div><div class="check"><div class="ico">4</div><span>Monitor & alert</span><span class="done">Done</span></div></div><div class="token">Task-bound micro-token · supplier.read · TTL 30 sec</div></div><div>${term('BLUE IDENTITY','LEAST PRIVILEGE',['validate intent SupplierBot','revoke broad_token','issue micro_token --scope supplier.read --ttl 30s','restrict east-west calls','<span class="good">supplier validation = OK</span>'])}</div></div></div>`;
else if(s.layout==='identity_green')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-green"><div class="panel-title">GREEN · Identity governance</div><div class="policy-list"><div class="policy">Purpose-bound access</div><div class="policy">Approval required for scope expand</div><div class="policy">Continuous validation enabled</div><div class="policy">TTL and delegation rules updated</div></div></div><div class="panel"><div class="panel-title">Governance propagation</div><div class="wave-field"><div class="wave-core">◌</div><div class="wave"></div><div class="wave w2"></div><div class="wave w3"></div></div></div></div></div>`;
else if(s.layout==='payment_red')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-gold"><div class="panel-title">Payment in flight</div><div class="amount"><small>Payment amount</small><strong>€18,400,000</strong><span>Vendor A · Pending approval</span></div></div><div class="panel soft-red"><div class="panel-title">RED · Business-objective prediction</div>${term('RED OBJECTIVE','FINANCIAL RISK',['correlate prior routes','model business outcomes','payment manipulation score = 0.87','data theft score = 0.34','persistence score = 0.29','<span class="bad">predict = PAYMENT MANIPULATION</span>'])}<div class="big-label" style="color:var(--red);font-size:16px">Potential loss: €18,400,000</div></div></div></div>`;
else if(s.layout==='payment_crisis')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-gold"><div class="panel-title">Treasury payment</div><div class="amount"><small>Current value at risk</small><strong>€18.4M</strong><span>Fictional supplier payment</span></div></div><div class="panel"><div class="panel-title">Transaction path</div>${paymentSvg(false)}<div class="payment-rail"><div class="pay-step">Supplier validation</div><div class="pay-step hot">Beneficiary mutation</div><div class="pay-step">Payment release</div></div><div class="big-label" style="color:var(--red);font-size:17px">ATTEMPTED ACTION: beneficiary.write</div></div></div></div>`;
else if(s.layout==='payment_blue')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-blue"><div class="panel-title">BLUE · Transaction enforcement</div><div class="checklist"><div class="check"><div class="ico">1</div><span>Hold transaction</span><span class="done">Done</span></div><div class="check"><div class="ico">2</div><span>Block beneficiary change</span><span class="done">Done</span></div><div class="check"><div class="ico">3</div><span>Notify approvers</span><span class="done">Done</span></div><div class="check"><div class="ico">4</div><span>Open case</span><span class="done">Done</span></div></div><div class="freeze">PAYMENT FROZEN · €18.4M PROTECTED</div></div><div>${term('BLUE PAYMENT','TRANSACTION CONTROL',['evaluate beneficiary.write','compare original intent = supplier validation','decision = DENY','freeze payment-18400k','verify approved flows = OK','<span class="good">customer impact = NONE</span>'])}</div></div></div>`;
else if(s.layout==='payment_green')h=`<div class="visual-inner"><div class="grid2"><div class="panel soft-green"><div class="panel-title">GREEN · Workflow immunity</div><div class="policy-list"><div class="policy">New control: beneficiary integrity</div><div class="policy">Dual approval for changes</div><div class="policy">High-risk route blocking</div><div class="policy">Behavioral monitoring</div></div></div><div class="panel"><div class="panel-title">Payment workflow coverage</div><div class="wave-field"><div class="wave-core">¤</div><div class="wave"></div><div class="wave w2"></div><div class="wave w3"></div></div></div></div></div>`;
else if(s.layout==='summary')h=`<div class="visual-inner"><div class="grid2"><div>${term('ATTACKER ADAPTS AGAIN','ACTIVE',['refine technique','obfuscate payload','change infrastructure','attempt re-entry','moving slower','testing defenses'])}</div><div class="panel soft-green"><div class="panel-title">Executive scorecard</div><div class="scoregrid"><div class="score"><small>ATTACK STAGES</small><strong>5</strong><span>Stopped</span></div><div class="score"><small>EMAIL</small><strong>1</strong><span>Quarantined</span></div><div class="score"><small>IDENTITY</small><strong>1</strong><span>Misuse blocked</span></div><div class="score"><small>VALUE</small><strong>€18.4M</strong><span>Protected</span></div></div><div class="policy-list" style="margin-top:12px"><div class="policy">Technique changed; objective stayed the same</div><div class="policy">RED recognized the objective</div><div class="policy">BLUE contained the new route</div><div class="policy">GREEN updated the policy family</div></div></div></div></div>`;
$('visual').innerHTML=h}
(async()=>{const ss=await data(),id=document.body.dataset.scene,i=ss.findIndex(x=>x.id===id),s=ss[i],prev=ss[Math.max(0,i-1)].id+'.html',next=ss[Math.min(ss.length-1,i+1)].id+'.html';theme(s);renderChapters(s);renderLifecycle(s);startClock(i);$('actLabel').textContent=`CHAPTER ${s.act_no} · ${s.act}`;$('title').textContent=s.title;$('subtitle').textContent=s.subtitle;$('focusBadge').textContent=s.focus;$('attacker').textContent=s.attacker;$('business').textContent=s.business;$('impact').textContent=s.impact;$('businessTag').textContent=s.business_tag||'';$('impactIcon').textContent=impactIcon(s);$('focus').textContent=s.focus;$('callout').textContent=s.callout;$('redMode').textContent=s.red_mode;$('blueMode').textContent=s.blue_mode;$('greenMode').textContent=s.green_mode;$('redSummary').textContent=(s.red||[])[0]||'';$('blueSummary').textContent=(s.blue||[])[0]||'';$('greenSummary').textContent=(s.green||[])[0]||'';$('prev').href=prev;$('next').href=next;$('topPrev').href=prev;$('topNext').href=next;renderVisual(s);renderRuntime(s);updateButtons();$('autoplayBtn').onclick=()=>{set(STORE.auto,!get(STORE.auto,false));updateButtons();if(get(STORE.auto,false))nextLater(next,4200)};$('narrationBtn').onclick=()=>{set(STORE.nar,!get(STORE.nar,true));updateButtons();narrate(s,next)};$('replayBtn').onclick=()=>narrate(s,next);document.addEventListener('keydown',e=>{if(e.key==='ArrowRight')location.href=next;if(e.key==='ArrowLeft')location.href=prev;if(e.key.toLowerCase()==='a')$('autoplayBtn').click();if(e.key.toLowerCase()==='n')$('narrationBtn').click()});if(s.layout==='chapter'){const c=$('chapterCurtain');$('curtainAct').textContent=`CHAPTER ${s.act_no}`;$('curtainTitle').textContent=s.act;$('curtainSub').textContent=s.subtitle;c.classList.remove('hidden');setTimeout(()=>c.classList.add('hidden'),2100)}setTimeout(()=>narrate(s,next),1300)})();
